﻿
using Microsoft.Extensions.DependencyInjection;
using Microsoft.FluentUI.AspNetCore.Components;
using Microsoft.JSInterop;
using $safeprojectname$.Data;


namespace $safeprojectname$
{
    public static class AllServices
    {
        public static ServiceCollection UseServices(this ServiceCollection serviceCollection)
        {
            serviceCollection.AddWpfBlazorWebView();
#if DEBUG   
            serviceCollection.AddBlazorWebViewDeveloperTools();
            serviceCollection.AddLogging();

#endif     
           
            serviceCollection.AddSingleton<WeatherForecastService>();
            serviceCollection.AddFluentUIComponents();
            return serviceCollection;
        }
    }
}
