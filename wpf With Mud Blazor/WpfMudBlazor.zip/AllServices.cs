﻿using Microsoft.Extensions.DependencyInjection;
using MudBlazor.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Data;
using static $safeprojectname$.Pages.FetchData;

namespace $safeprojectname$
{
    public static class AllServices
    {
        public static ServiceCollection UseServices(this ServiceCollection serviceCollection)
        {
            serviceCollection.AddWpfBlazorWebView();
#if DEBUG
            serviceCollection.AddBlazorWebViewDeveloperTools();
            serviceCollection.AddLogging();

#endif
            serviceCollection.AddSingleton<WeatherForecastService>();
           serviceCollection.AddMudServices();
            return serviceCollection;
        }
    }
}
